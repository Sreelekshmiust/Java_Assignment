package com.employee.details.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Employee {

    @Id
    private Integer employeeId;
    private String employeeName;
    private  String employeeDepartment;
    private float salary;
}

package com.employee.details.exception;

public class EmployeeAlreadyExist extends Exception{

    public EmployeeAlreadyExist(String message){
        super(message);
    }
}

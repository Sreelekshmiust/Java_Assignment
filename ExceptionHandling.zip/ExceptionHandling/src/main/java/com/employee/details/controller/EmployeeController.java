package com.employee.details.controller;

import com.employee.details.entities.Employee;
import com.employee.details.exception.EmployeeAlreadyExist;
import com.employee.details.exception.EmployeeNotFound;
import com.employee.details.repositories.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping
public class EmployeeController {

    @Autowired
    EmployeeRepository employeeRepository;

    @PostMapping
    public ResponseEntity<?> createEmployee(@RequestBody Employee employee){
        try {
            Optional<Employee> op = employeeRepository.findById(employee.getEmployeeId());
            if (op.isPresent()) {
                throw new EmployeeAlreadyExist("Employee with id " + employee.getEmployeeId() + " already exist");
            }
            Employee createdEmployee = employeeRepository.save(employee);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdEmployee);
        }catch (EmployeeAlreadyExist ex){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
        }
    }

    @GetMapping("{employeeId}")
    public  ResponseEntity<Employee> fetchEmployeeById(@PathVariable Integer employeeId) throws EmployeeNotFound {
        Optional<Employee> op = employeeRepository.findById(employeeId);
        if(op.isEmpty())
        {
            throw new EmployeeNotFound("Employee with id " +employeeId + " not found");
        }
        Employee fetchedEmployee = op.get();
     return ResponseEntity.ok(fetchedEmployee);
    }

    @GetMapping
    public List<Employee> fetchEmployeeList()
    {
        return employeeRepository.findAll();
    }

    @PutMapping
    public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee) throws EmployeeNotFound {
        Optional<Employee> op = employeeRepository.findById(employee.getEmployeeId());
        if(op.isPresent()) {
            Employee updatedEmployee = op.get();
            updatedEmployee.setEmployeeName(employee.getEmployeeName());
            updatedEmployee.setEmployeeDepartment(employee.getEmployeeDepartment());
            updatedEmployee.setSalary(employee.getSalary());
            employeeRepository.save(updatedEmployee);
            return ResponseEntity.status(HttpStatus.OK).body(updatedEmployee);
        }
            throw new EmployeeNotFound("The employee with id " +employee.getEmployeeId() + " not found");
    }

    @DeleteMapping
    public String deleteEmployee(@RequestBody Employee employee){
        employeeRepository.deleteById(employee.getEmployeeId());
        return "The employee with id " +employee.getEmployeeId() + " is deleted";
    }
}
